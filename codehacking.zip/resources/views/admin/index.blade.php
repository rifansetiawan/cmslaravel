@extends('layouts.admin')

@section('judul-card')
    <h1>Admin</h1>
@endsection

@section('konten-admin')

@endsection

