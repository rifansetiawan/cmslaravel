<?php $__env->startSection('judul-card'); ?>
    <h2>Edit Posts</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>

    <?php echo $__env->make('includes.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="row">

    <div class="col-sm-4">
        <?php if($post->photo): ?>
            <img height="100" src="<?php echo e($post->photo->file); ?>" alt="">
        <?php else: ?>
            <img height="50" src="<?php echo e('http://placehold.it/400x400'); ?>" alt="">
        <?php endif; ?>

    </div>

    <?php echo Form::model($post,['method'=>'PATCH','action'=>['AdminPostsController@update',$post->id], 'files'=>true]); ?>


    <div class='form-group'>
    <?php echo Form::label('title','Title : '); ?>

    <?php echo Form::text('title',null, ['class' => 'form-control']); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::label('category_id','Category : '); ?>

    <?php echo Form::select('category_id',array(0=>'Choose Category')+$categories,null,  ['class'=>'form-control']); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::label('photo_id','Photo : '); ?>

    <?php echo Form::file('photo_id',null, ['class'=>['form-control']]); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::label('body','Content : '); ?>

    <?php echo Form::textarea('body',null, ['class' => 'form-control', 'rows'=>3]); ?>

    </div>

    <div class="row float-right">
        <div class='form-group'>
            <?php echo Form::submit('Update Post', ['class'=>'btn btn-primary']); ?>

        </div>
            <?php echo Form::close(); ?>


        &nbsp;
        &nbsp;
        <?php echo Form::open(['method'=>'DELETE','action'=>['AdminPostsController@destroy',$post->id]]); ?>

        <div class='form-group'>
        <?php echo Form::submit('Delete Post', ['class'=>'btn btn-danger']); ?>

        </div>
        <?php echo Form::close(); ?>


    </div>


    </div>




    
        <?php echo $__env->make('includes/error_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>