<script src="https://cdn.tiny.cloud/1/dudexaqik5qno9czm0ab8fro6z04bx6rzzpia5z7v984cjxf/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script>tinymce.init({selector:'textarea'});</script>
<?php /**PATH C:\xampp\htdocs\codehacking\resources\views/includes/tinyeditor.blade.php ENDPATH**/ ?>