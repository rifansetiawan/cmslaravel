<?php $__env->startSection('judul-card'); ?>
    <h2>Edit User</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>


    <div class="row">
        <div class="col-sm-3">
            <br>
            <?php if($user->photos_id): ?>
            <img height="300" src="<?php echo e($user->photo->file); ?>" alt="" class="img-responsive img-rounded" >
            <?php else: ?>
            <img src="http://placehold.it/400x400" alt="" class="img-responsive img-rounded">
            <?php endif; ?>

        </div>
        <div class="col-sm-9">
            <?php echo Form::model($user,['method'=>'PATCH','action'=>['AdminUsersController@update',$user->id],'files'=>true]); ?>


            <div class="form-group">
                <?php echo Form::label('name','Name : '); ?>

                <?php echo Form::text('name',null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('email','Email : '); ?>

                <?php echo Form::email('email',null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('role_id','Role : '); ?>

                <?php echo Form::select('role_id',[''=>'Choose Options']+$role,null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('is_active','Status : '); ?>

                <?php echo Form::select('is_active',array(1=>'Active',0=>'Not Active'),null, ['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
                <?php echo Form::label('password','Password : '); ?>

                <?php echo Form::password('password',['class'=>'form-control']); ?>

            </div>


            <div class="form-group">
                <?php echo Form::label('photos_id','Photo : '); ?>

                <?php echo Form::file('photos_id', null,['class'=>'form-control']); ?>

            </div>

            <div class="row float-right">
                <div class="col-sm-5">
                    <?php echo Form::submit('Edit User', ['class'=>'btn btn-primary']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <div class="col-sm-5">
                    <?php echo Form::open(['method'=>'DELETE','action'=>['AdminUsersController@destroy',$user->id]]); ?>

                    <?php echo Form::submit('Delete User', ['class'=>'btn btn-danger myWish']); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>

        </div>


    </div>
    <?php echo $__env->make('includes.error_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>