<?php $__env->startSection('judul-card'); ?>

<h2>Images</h2>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>

    <form action="/delete/selected" method="post" class="form-inline">

        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('delete')); ?>


        <div class="form-group">
            <select name="checkBoxArray" id="" class="form-control">
                <option value="">Delete</option>

            </select>
        </div>
        &nbsp;
        <div class="form-group">
            <input type="submit" name="delete_all" class="form-control btn btn-primary">
        </div>

        <table class='table table-hover'>
            <thead>
                <tr>
                    <th><input type="checkbox" id="options"></th>
                    <th>ID</th>
                    <th>File</th>
                    <th>Created Time</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><input class="checkBoxes" type="checkbox" name="checkBoxArray[]"  value="<?php echo e($photo->id); ?>"></td>
                        <td><?php echo e($photo->id); ?></td>
                        
                        <td><img height="50" src="<?php echo e($photo->file); ?>" alt=""></td>
                        <td><?php echo e($photo->created_at->diffForHumans()); ?></td>
                        <td>

                            <input type="hidden" name="photo" value="<?php echo e($photo->id); ?>">

                            <div class="form-group">
                                <input type="submit" name="delete_single" value="delete" class="btn btn-danger">
                            </div>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

    </form>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script>
        $(document).ready(function(){
            $('#popoverData').popover();
            $('#popoverOption').popover({ trigger: "hover" });
            console.log('tai');

            $('#options').click(function(){

                if(this.checked){
                    $('.checkBoxes').each(function(){
                        this.checked = true;
                    });
                }
                else{
                    $('.checkBoxes').each(function(){
                        this.checked = false;
                    });
                }


                // console.log('it works')
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/media/index.blade.php ENDPATH**/ ?>