<?php $__env->startSection('judul-card'); ?>
    <h2>Posts</h2>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('konten-admin'); ?>

    <table class='table table-hover'>
        <thead>
            <tr>
                <th>Post ID</th>
                <th>User</th>
                <th>Category</th>
                <th>Photo</th>
                <th>Title</th>
                <th>Content</th>
                <th>Created at</th>
                <th>Updated at</th>
            </tr>
        </thead>
        <tbody>
            <?php if($posts): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($post->id); ?></td>
                    <td><?php echo e($post->user->name); ?></td>

                    <?php if($post->category): ?>
                    <td><?php echo e($post->category->name); ?></td>
                    <?php else: ?>
                    <td>Uncategorized</td>
                    <?php endif; ?>

                    <?php if($post->photo): ?>
                    
                    <td><img height="50" src="<?php echo e($post->photo->file); ?>" alt=""></td>
                    <?php else: ?>
                    <td><img height="50" src="<?php echo e('http://placehold.it/400x400'); ?>" alt=""></td>
                    <?php endif; ?>

                    <td><a href="<?php echo e(route('admin.posts.edit', $post->id)); ?>"><?php echo e($post->title); ?></a></td>
                    <td><?php echo e($post->body); ?></td>
                    <td><?php echo e($post->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($post->updated_at->diffForHumans()); ?></td>
                    <td><a href="<?php echo e(route('home.post', $post->slug)); ?>">View Post</a></td>
                    
                    <td><a href="<?php echo e(route('admin.replies.show', $post->id)); ?>">View Comments of This Post</a></td>
                </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>

        </tbody>
    </table>

    <div class="row justify-content-center">
        <div class="col-sm-2 col-sm-offset-2">
            <?php echo e($posts->render()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>