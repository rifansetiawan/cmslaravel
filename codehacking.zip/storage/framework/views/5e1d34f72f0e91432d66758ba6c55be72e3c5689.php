<?php $__env->startSection('judul-card'); ?>
    <h2>Create Posts</h2>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('konten-admin'); ?>
    <?php echo $__env->make('includes.tinyeditor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo Form::open(['method'=>'POST','action'=>'AdminPostsController@store', 'files'=>true]); ?>


    <div class='form-group'>
    <?php echo Form::label('title','Title : '); ?>

    <?php echo Form::text('title',null, ['class' => 'form-control']); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::label('category_id','Category : '); ?>

    <?php echo Form::select('category_id',array(''=>'Choose Category')+$categories,null,  ['class'=>'form-control']); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::label('photo_id','Photo : '); ?>

    <br>
    <?php echo Form::file('photo_id',null, ['class'=>'form-control']); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::label('body','Content : '); ?>

    <?php echo Form::textarea('body',null, ['class' => 'form-control', 'rows'=>3]); ?>

    </div>

    <div class='form-group'>
    <?php echo Form::submit('Submit', ['class'=>'btn btn-primary']); ?>

    </div>
    <?php echo Form::close(); ?>



    
        <?php echo $__env->make('includes/error_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/posts/create.blade.php ENDPATH**/ ?>