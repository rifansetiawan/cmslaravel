<?php $__env->startSection('judul-card'); ?>
    <h2>Comments</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>

    <table class='table table-hover'>
        <?php if(count($comments)>0): ?>
        <thead>
            <tr>
            <th>ID</th>
            <th>Author</th>
            <th>Email</th>
            <th>Comment</th>
            <th>Created at</th>
            <th>Status</th>
            </tr>
        </thead>
        <tbody>

                <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($comment->id); ?></td>
                        <td><?php echo e($comment->author); ?></td>
                        <td><?php echo e($comment->email); ?></td>
                        <td><?php echo e($comment->body); ?></td>
                        <td><?php echo e($comment->created_at->diffForHumans()); ?></td>
                        <td><?php echo e($comment->is_active); ?></td>
                        <td><a href="<?php echo e(route('home.post', $comment->post->id)); ?>">View Post</a></td>
                        <td><a href="<?php echo e(route('admin.replies.show', $comment->id)); ?>">View Replies</a></td>
                        <td>
                            <?php echo Form::open(['method'=>'PATCH','action'=>['PostCommentsController@update',$comment->id]]); ?>


                            <?php if($comment->is_active == 0): ?>
                                <?php echo Form::hidden('is_active', 1); ?>

                                <div class='form-group'>
                                <?php echo Form::submit('Approve', ['class'=>'btn btn-primary']); ?>

                                </div>
                            <?php else: ?>
                                <?php echo Form::hidden('is_active', 0); ?>

                                <div class='form-group'>
                                <?php echo Form::submit('Approved', ['class'=>'btn btn-secondary']); ?>

                                </div>

                            <?php endif; ?>

                            <?php echo Form::close(); ?>

                        </td>
                        <td>
                            <?php echo Form::open(['method'=>'DELETE','action'=>['PostCommentsController@destroy',$comment->id]]); ?>

                            <div class='form-group'>
                            <?php echo Form::submit('Delete', ['class'=>'btn btn-danger']); ?>

                            </div>
                            <?php echo Form::close(); ?>

                        </td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
        <?php else: ?>
        <h1>There is no comment here</h1>
        <?php endif; ?>
    </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/comments/index.blade.php ENDPATH**/ ?>