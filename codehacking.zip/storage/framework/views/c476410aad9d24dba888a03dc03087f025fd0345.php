<?php $__env->startSection('judul-card'); ?>
    <h1>Admin</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/index.blade.php ENDPATH**/ ?>