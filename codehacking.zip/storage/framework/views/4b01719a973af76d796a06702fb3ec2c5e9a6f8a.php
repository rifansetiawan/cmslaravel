<?php $__env->startSection('judul-card'); ?>

    <h2>Comment</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>

    <?php if(count($replies) > 0 ): ?>
    <table class='table table-hover'>
        <thead>
            <tr>
                <th>Author</th>
                <th>Photo</th>
                <th>Email</th>
                <th>Body</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td><?php echo e($reply->author); ?></td>
                <td><img height="64" src="<?php echo e($reply->photo); ?>" alt=""></td>
                <td><?php echo e($reply->email); ?></td>
                <td><?php echo e($reply->body); ?></td>
                <td><?php echo e($reply->created_at->diffForHumans()); ?></td>
                <td><?php echo e($reply->id); ?></td>
                <td>
                    <?php if($reply->is_active == 0): ?>
                        <?php echo Form::open(['method'=>'PATCH','action'=>['CommentRepliesController@update',$reply->id]]); ?>

                        <div class='form-group'>
                        <?php echo Form::hidden('is_active',1); ?>

                        <?php echo Form::submit('Approve', ['class'=>'btn btn-primary']); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    <?php else: ?>
                        <?php echo Form::open(['method'=>'PATCH','action'=>['CommentRepliesController@update',$reply->id]]); ?>

                        <div class='form-group'>
                        <?php echo Form::hidden('is_active',0); ?>

                        <?php echo Form::submit('Approved', ['class'=>'btn btn-secondary']); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    <?php endif; ?>

                </td>
                <td>
                    <?php echo Form::open(['method'=>'DELETE','action'=>['CommentRepliesController@destroy',$reply->id]]); ?>

                    <div class='form-group'>
                    <?php echo Form::submit('DELETE', ['class'=>'btn btn-danger']); ?>

                    </div>
                    <?php echo Form::close(); ?>


                </td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
    </table>
    <?php else: ?>
        <h2>The is no replies of this comment</h2>

    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/comments/replies/show.blade.php ENDPATH**/ ?>