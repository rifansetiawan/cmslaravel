<?php $__env->startSection('judul-card'); ?>

    <h2>Comment</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten-admin'); ?>
    <table class='table table-hover'>
        <thead>
            <tr>
                <th>Author</th>
                <th>Photo</th>
                <th>Email</th>
                <th>Body</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>

            <tr>
                <?php $__currentLoopData = $commentreplies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($reply->author); ?></td>
                <td><?php echo e($reply->photo); ?></td>
                <td><?php echo e($reply->email); ?></td>
                <td><?php echo e($reply->body); ?></td>
                <td><?php echo e($reply->created_at->diffForHumans()); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>



        </tbody>
    </table>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/admin/comments/replies/index.blade.php ENDPATH**/ ?>