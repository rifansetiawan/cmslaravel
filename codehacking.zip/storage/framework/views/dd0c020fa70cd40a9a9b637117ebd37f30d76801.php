<?php $__env->startSection('content'); ?>
<div class="col-lg-8">

    <!-- Blog Post -->

    <!-- Title -->
    <h1><?php echo e($post->title); ?></h1>

    <!-- Author -->
    <p class="lead">
        by <a href="#"><?php echo e($post->user->name); ?></a>
    </p>

    <hr>

    <!-- Date/Time -->
    <p><span class="glyphicon glyphicon-time"></span> Posted <?php echo e($post->created_at->diffForHumans()); ?></p>

    <hr>

    <!-- Preview Image -->
    <img class="img-responsive" src="<?php echo e($post->photo->file); ?>" alt="">

    <hr>

    <!-- Post Content -->
<p class="lead"> <?php echo $post->body; ?></p>

    <hr>

    <!-- Blog Comments -->

    <!-- Comments Form -->
    <?php if(Auth::check()): ?>

        <div class="well">
            <h4>Leave a Comment:</h4>
            <?php echo Form::open(['method'=>'POST','action'=>'PostCommentsController@store']); ?>

                <div type="hidden" class='form-group'>
                    <?php echo Form::hidden('post_id', $post->id ); ?>

                </div>
                <div type="hidden" >
                    <?php echo Form::hidden('is_active', 0); ?>

                </div>
                <div class='form-group'>
                    <?php echo Form::label('body','Body : '); ?>

                    <?php echo Form::textarea('body',null, ['class' => 'form-control', 'rows'=>3] ); ?>

                </div>
                <div class='form-group'>
                    <?php echo Form::submit('Submit', ['class'=>'btn btn-primary']); ?>

                </div>
            <?php echo Form::close(); ?>

        </div>

    <?php endif; ?>


    <hr>

    <!-- Posted Comments -->

    <!-- Comment -->
    <?php if(count($comments) > 0): ?>



        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($comment->is_active == 1): ?>
            <div class="media">
                <a class="pull-left" href="#">
                    <img height="64" class="media-object" src="<?php echo e($comment->photo); ?>" alt="">
                </a>
                <div class="media-body">
                    <h4 class="media-heading"><?php echo e($comment->author); ?>

                        <small><?php echo e($comment->created_at->diffForHumans()); ?></small>
                    </h4>
                    <?php echo e($comment->body); ?>

                    <?php $__currentLoopData = $comment->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($comment->replies) > 0 and $reply->is_active == 1): ?>

                        <div class="media">
                            <a class="pull-left" href="#">
                                <img height="64" class="media-object" src="<?php echo e($reply->photo); ?>" alt="" width="64">
                            </a>
                            <div class="media-body">
                                <h4 class="media-heading"><?php echo e($reply->author); ?>

                                    <small><?php echo e($reply->created_at->diffForHumans()); ?></small>
                                </h4>
                                <?php echo e($reply->body); ?>

                            </div>
                            <br>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::check()): ?>
                        <?php echo Form::open(['method'=>'POST','action'=>'CommentRepliesController@createReply']); ?>


                        <?php echo Form::hidden('comment_id', $comment->id ); ?>

                        <input type="hidden" name="is_active" value="0">
                        <div class='form-group'>
                            <?php echo Form::label('body','Body : '); ?>

                            <?php echo Form::text('body',null, ['class' => 'form-control','rows'=>3]); ?>

                        </div>
                        <div class='form-group'>
                            <?php echo Form::submit('submit', ['class'=>'btn btn-primary']); ?>

                        </div>
                        <?php echo Form::close(); ?>


                    <?php endif; ?>



                </div>
            </div>

            <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php endif; ?>




</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blog-post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\codehacking\resources\views/post.blade.php ENDPATH**/ ?>